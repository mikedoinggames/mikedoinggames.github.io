﻿using FPL_Track_Test.FPLAPI;
using FPL_Track_Test.Helpers;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;

namespace FPL_Track_Test.Controllers
{
    public class FPLAPIController : Controller
    {
        [HttpGet]
        public JsonResult GetPlayersForScatterChart(int id)
        {
            List<Player> players = new List<Player>();
            List<ScatterChartSeriesItem> result = new List<ScatterChartSeriesItem>();
            using (WebClient wc = new WebClient())
            {
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Ssl3 | SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;
                var json = wc.DownloadString(@"https://fantasy.premierleague.com/drf/bootstrap");


                JObject jObj = JObject.Parse(json);
                JToken jT = jObj["elements"];
                players = jT.ToObject<List<Player>>();
            }
            foreach(Player p in players.Where(p => p.element_type == id))
            {
                ScatterChartSeriesItem s = new ScatterChartSeriesItem() {
                    name = p.web_name,
                    x = p.now_cost / 10,
                    y = p.total_points,
                    key = p.id.ToString()
                };
                result.Add(s);
            }
            return Json(result, JsonRequestBehavior.AllowGet);
            
        }




    }
}