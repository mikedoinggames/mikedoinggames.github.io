﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;

namespace FPL_Track_Test.FPLAPI
{
    public class APICallers
    {
        public static Player GetPlayer(int id)
        {
            Player p = new Player();
            List<Player> players = new List<Player>();
            using (WebClient wc = new WebClient())
            {
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Ssl3 | SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;
                var json = wc.DownloadString(@"https://fantasy.premierleague.com/drf/bootstrap");


                JObject jObj = JObject.Parse(json);
                JToken jT = jObj["elements"];
                players = jT.ToObject<List<Player>>();
            }
            p = players.Where(pl => pl.id == id).FirstOrDefault();
            return p;
        }
    }
}